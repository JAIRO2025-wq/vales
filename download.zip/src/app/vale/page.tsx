"use client";

import React, { Suspense, useState, useEffect, useRef } from "react";
import { useSearchParams, useRouter } from "next/navigation";
import { VoucherCard } from "@/components/vale/VoucherCard";
import { Button } from "@/components/ui/button";
import { Printer, XCircle, Share2, CheckCircle2, AlertCircle, Loader2, FileCheck, Eye, Send } from "lucide-react";
import { checkVoucherStatusAction, savePdfAction, saveVoucherAction, type VoucherRecord } from "@/app/actions/vouchers";
import { Card, CardContent } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { CONFIG } from "@/lib/config";

function ValeContent() {
  const searchParams = useSearchParams();
  const router = useRouter();
  const { toast } = useToast();
  const autoSaveTriggered = useRef(false);
  
  const [qrSignUrl, setQrSignUrl] = useState("");
  const [qrFileUrl, setQrFileUrl] = useState("");
  const [rawSignUrl, setRawSignUrl] = useState("");
  const [rawFileUrl, setRawFileUrl] = useState("");
  const [voucherStatus, setVoucherStatus] = useState<VoucherRecord | null>(null);
  const [isChecking, setIsChecking] = useState(true);
  const [isSyncing, setIsSyncing] = useState(false);
  const [isSavingPdf, setIsSavingPdf] = useState(false);
  const [hasDismissedModal, setHasDismissedModal] = useState(false);
  
  const voucherData = {
    fila: searchParams.get("fila") || "",
    sheet: searchParams.get("sheet") || "",
    id: searchParams.get("id") || "FNT-0000",
    fecha: searchParams.get("fecha") || "",
    entregado: searchParams.get("entregado") || "",
    rubro: searchParams.get("rubro") || "",
    numVale: searchParams.get("numVale") || "",
    monto: searchParams.get("monto") || "0.00",
    sucursal: searchParams.get("sucursal") || "CENTRO",
  };

  useEffect(() => {
    const initVoucher = async () => {
      try {
        const status = await checkVoucherStatusAction(voucherData.id, voucherData.fecha);
        if (status) {
          setVoucherStatus(status);
        } else {
          const timestamp = new Date().toISOString();
          await saveVoucherAction({
            ...voucherData,
            firmado: false,
            timestamp: timestamp
          } as any);
          const newStatus = await checkVoucherStatusAction(voucherData.id, voucherData.fecha);
          if (newStatus) setVoucherStatus(newStatus);
        }
      } catch (e) {
        console.error("Error inicializando vale:", e);
      } finally {
        setIsChecking(false);
      }
    };
    
    initVoucher();
    
    const interval = setInterval(async () => {
      const status = await checkVoucherStatusAction(voucherData.id, voucherData.fecha);
      if (status) setVoucherStatus(status);
    }, 4000); 
    
    return () => clearInterval(interval);
  }, [voucherData.id, voucherData.fecha]);

  useEffect(() => {
    if (typeof window !== "undefined") {
      const params = new URLSearchParams();
      Object.entries(voucherData).forEach(([k, v]) => params.set(k, v as string));

      const signUrl = `${window.location.origin}/firmar?${params.toString()}`;
      setRawSignUrl(signUrl);
      setQrSignUrl(`https://api.qrserver.com/v1/create-qr-code/?size=400x400&ecc=M&margin=1&data=${encodeURIComponent(signUrl)}`);

      const fileUrl = `${window.location.origin}/adjuntar?${params.toString()}`;
      setRawFileUrl(fileUrl);
      setQrFileUrl(`https://api.qrserver.com/v1/create-qr-code/?size=400x400&ecc=M&margin=1&data=${encodeURIComponent(fileUrl)}&color=059669`);
    }
  }, []);

  const handleArchiveVoucher = async (silent = false) => {
    const valeElement = document.getElementById('valeContainer');
    if (!valeElement) return false;

    if (!silent) setIsSyncing(true);
    else setIsSavingPdf(true);

    try {
      const html2canvas = (await import("html2canvas")).default;
      const { jsPDF } = await import("jspdf");

      const canvas = await html2canvas(valeElement, {
        scale: 2,
        useCORS: true,
        backgroundColor: "#ffffff",
        logging: false
      });

      const imgData = canvas.toDataURL("image/jpeg", 0.95);
      const pdf = new jsPDF("p", "mm", "a4");
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = (canvas.height * pdfWidth) / canvas.width;
      
      pdf.addImage(imgData, "JPEG", 0, 10, pdfWidth, pdfHeight);
      const pdfBase64 = pdf.output("datauristring");

      await savePdfAction(voucherData.id, voucherData.fecha, voucherData.numVale, pdfBase64);

      const publicUrl = "https://vales01.modulos.uk";
      const params = new URLSearchParams();
      Object.entries(voucherData).forEach(([k, v]) => params.set(k, v as string));
      const viewLink = `${publicUrl}/vale?${params.toString()}`;

      await fetch(CONFIG.API_URL, {
        method: "POST",
        mode: "no-cors",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          fila: voucherData.fila,
          sheet: voucherData.sheet,
          id: voucherData.id,
          pdfUrl: viewLink,
          metodo: "updatePdf"
        }),
      });

      if (!silent) {
        toast({ title: "Completado", description: "El vale ha sido archivado y enviado a Google." });
      }
      
      setVoucherStatus(prev => prev ? { ...prev, hasPdf: true } : null);
      return true;
    } catch (err) {
      console.error("Error en archivado:", err);
      if (!silent) toast({ variant: "destructive", title: "Error", description: "No se pudo generar el archivo PDF." });
      return false;
    } finally {
      setIsSyncing(false);
      setIsSavingPdf(false);
    }
  };

  useEffect(() => {
    if ((voucherStatus?.firmado || voucherStatus?.motivoOmitido) && !voucherStatus?.hasPdf && !autoSaveTriggered.current && !isChecking) {
      autoSaveTriggered.current = true;
      setTimeout(() => handleArchiveVoucher(true), 3000);
    }
  }, [voucherStatus?.firmado, voucherStatus?.motivoOmitido, voucherStatus?.hasPdf, isChecking]);

  const handlePrint = () => window.print();

  const handleSkipSignature = () => {
    const params = new URLSearchParams(searchParams.toString());
    params.set("mode", "skip");
    router.push(`/firmar?${params.toString()}`);
  };

  const handleShareComprobante = async () => {
    if (navigator.share) {
      const params = new URLSearchParams(searchParams.toString());
      try {
        await navigator.share({
          title: 'Adjuntar Comprobante Flynet',
          url: `${window.location.origin}/adjuntar?${params.toString()}`
        });
      } catch (err) {}
    }
  };

  const handleAutoSavePdfAndEnterConsultation = async () => {
    if (!voucherStatus?.hasPdf) {
      await handleArchiveVoucher(true);
    }
    setHasDismissedModal(true);
  };

  if (isChecking) {
    return (
      <div className="min-h-screen bg-gray-100 flex flex-col items-center justify-center gap-4">
        <Loader2 className="w-12 h-12 animate-spin text-primary" />
        <p className="font-headline font-bold text-primary animate-pulse text-sm">SINCRONIZANDO DATOS...</p>
      </div>
    );
  }

  const isSigned = voucherStatus && (voucherStatus.firmado || !!voucherStatus.motivoOmitido);

  return (
    <div className="min-h-screen bg-zinc-50 p-4 md:p-8 flex flex-col items-center gap-8 animate-in fade-in duration-500 print:bg-white print:p-0">
      {isSigned && !hasDismissedModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4 print:hidden">
          <Card className="w-full max-w-md shadow-2xl border-none overflow-hidden animate-in zoom-in duration-300">
            <div className={`h-2 ${voucherStatus.firmado ? 'bg-emerald-500' : 'bg-orange-500'}`} />
            <CardContent className="pt-8 pb-10 text-center space-y-6">
              {voucherStatus.firmado ? <CheckCircle2 className="w-16 h-16 text-emerald-600 mx-auto" /> : <AlertCircle className="w-16 h-16 text-orange-600 mx-auto" />}
              <div className="space-y-2">
                <h2 className="text-3xl font-black font-headline">VALE PROCESADO</h2>
                <p className="text-muted-foreground font-medium uppercase text-xs tracking-widest">Consulta de Auditoría Digital</p>
              </div>
              <div className="bg-muted/50 p-4 rounded-xl text-left border space-y-2">
                <div className="flex justify-between text-xs">
                  <span className="font-bold text-muted-foreground uppercase">Estado:</span>
                  <span className={`font-black ${voucherStatus.firmado ? 'text-emerald-700' : 'text-orange-700'}`}>
                    {voucherStatus.firmado ? 'FIRMADO DIGITALMENTE' : 'OMITIDO CON MOTIVO'}
                  </span>
                </div>
                {voucherStatus.hasPdf && (
                  <div className="pt-2 border-t mt-2 flex items-center gap-2 text-[10px] text-emerald-700 font-bold">
                    <FileCheck className="w-4 h-4" /> ARCHIVADO EN DATA DEL SERVIDOR
                  </div>
                )}
              </div>
              <div className="flex gap-3">
                <Button variant="outline" className="flex-1 h-12 font-bold" onClick={() => setHasDismissedModal(true)}>
                  <Eye className="w-4 h-4 mr-2" /> Revisar Vale
                </Button>
                <Button 
                  className="flex-1 h-12 font-bold bg-black hover:bg-zinc-800 text-white" 
                  onClick={handleAutoSavePdfAndEnterConsultation}
                  disabled={isSavingPdf}
                >
                  {isSavingPdf ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
                  Entendido
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      <header className="w-full max-w-[850px] flex flex-col sm:flex-row justify-between items-center gap-4 print:hidden">
        <div className="flex items-center gap-3">
           <div className="w-10 h-10 bg-black rounded-xl flex items-center justify-center text-white font-bold italic shadow-lg">F</div>
           <div className="flex flex-col">
              <h1 className="text-2xl font-bold font-headline text-black leading-tight tracking-tighter">Flynet Digital</h1>
              <span className="text-[10px] font-black uppercase tracking-widest opacity-60">
                {isSigned ? "AUDITORÍA • DOCUMENTO REGISTRADO" : "MODO PREPARACIÓN • ESPERANDO FIRMA"}
              </span>
           </div>
        </div>
        <div className="flex gap-2">
          {!isSigned ? (
            <>
              <Button variant="outline" onClick={handleSkipSignature} className="flex gap-2 border-destructive text-destructive hover:bg-destructive/10 h-12 px-6 font-bold">
                <XCircle className="w-5 h-5" /> OMITIR FIRMA
              </Button>
              <Button variant="outline" onClick={handleShareComprobante} className="flex gap-2 border-green-600 text-green-700 hover:bg-green-50 h-12 px-6 font-bold">
                <Share2 className="w-5 h-5" /> COMPARTIR QR
              </Button>
            </>
          ) : (
            <Button variant="default" onClick={() => handleArchiveVoucher()} disabled={isSyncing}
              className={`flex gap-2 h-12 px-6 shadow-xl font-bold transition-all text-white ${
                voucherStatus?.hasPdf ? 'bg-emerald-600 hover:bg-emerald-700' : 'bg-black hover:bg-zinc-800'
              }`}
            >
              {isSyncing ? <Loader2 className="w-5 h-5 animate-spin" /> : voucherStatus?.hasPdf ? <FileCheck className="w-5 h-5" /> : <Send className="w-5 h-5" />}
              {voucherStatus?.hasPdf ? "VALE ARCHIVADO" : "SINCRONIZAR AHORA"}
            </Button>
          )}
          <Button variant="default" onClick={handlePrint} className="flex gap-2 bg-zinc-200 hover:bg-zinc-300 text-black h-12 px-6 font-bold">
            <Printer className="w-5 h-5" /> IMPRIMIR
          </Button>
        </div>
      </header>

      <div className="relative">
        <VoucherCard 
          {...voucherData} 
          qrUrl={qrSignUrl} 
          qrFileUrl={qrFileUrl} 
          rawSignUrl={rawSignUrl}
          rawFileUrl={rawFileUrl}
          signatureUrl={voucherStatus?.firmaUrl}
          comprobanteUrl={voucherStatus?.comprobanteUrl}
          motivoOmitido={voucherStatus?.motivoOmitido}
        />
      </div>
      
      <p className="text-[10px] text-muted-foreground font-bold uppercase tracking-widest pb-10 print:hidden">
        Sistema de Gestión de Gastos Flynet • v3.0 Digital
      </p>
    </div>
  );
}

export default function ValePage() {
  return (
    <Suspense fallback={
      <div className="min-h-screen bg-gray-100 flex flex-col items-center justify-center gap-4">
        <Loader2 className="w-12 h-12 animate-spin text-primary" />
        <p className="font-headline font-bold text-primary">INICIANDO...</p>
      </div>
    }>
      <ValeContent />
    </Suspense>
  );
}
