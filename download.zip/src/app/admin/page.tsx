"use client";

import React, { useState, useEffect, Suspense } from "react";
import { useSearchParams, useRouter } from "next/navigation";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { CONFIG } from "@/lib/config";
import { getRecentCycles, type CycleInfo } from "@/lib/cycles";
import { getVouchersByCycleAction, formatVoucherForApi, type FormattedVoucher } from "@/app/actions/vouchers";
import { VoucherCard } from "@/components/vale/VoucherCard";
import { 
  LayoutDashboard, 
  Search, 
  TrendingUp, 
  FileText, 
  CheckCircle,
  Building2,
  Calendar,
  ExternalLink,
  AlertTriangle,
  Image as ImageIcon,
  MessageSquare,
  RefreshCcw,
  Info,
  Eye,
  Download,
  FileCheck,
  Receipt
} from "lucide-react";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

function AdminContent() {
  const searchParams = useSearchParams();
  const router = useRouter();
  
  const [cycles] = useState<CycleInfo[]>(getRecentCycles());
  const [selectedCycle, setSelectedCycle] = useState<string>(cycles[0].id);
  const [vales, setVales] = useState<FormattedVoucher[]>([]);
  const [loading, setLoading] = useState(true);
  const [previewVale, setPreviewVale] = useState<FormattedVoucher | null>(null);

  const [filterSucursal, setFilterSucursal] = useState("TODAS");
  const [filterSearch, setFilterSearch] = useState("");

  const loadData = async () => {
    setLoading(true);
    try {
      const rawData = await getVouchersByCycleAction(selectedCycle);
      
      const origin = typeof window !== 'undefined' ? window.location.origin : "https://vales01.modulos.uk";
      
      // Esperar a todas las transformaciones asíncronas
      const formatted = await Promise.all(rawData.map(v => formatVoucherForApi(v, origin)));
      setVales(formatted);
    } catch (err) {
      console.error("Error cargando vales:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [selectedCycle]);

  useEffect(() => {
    const suc = searchParams.get("sucursal");
    if (suc) setFilterSucursal(suc);
  }, [searchParams]);

  const stats = {
    total: vales.length,
    firmados: vales.filter(v => v.firmado).length,
    conTicket: vales.filter(v => v.comprobante).length,
    archivados: vales.filter(v => v.archivado).length,
    montoTotal: vales.reduce((acc, curr) => {
      const cleanMonto = parseFloat(curr.raw.monto.replace(/[^\d.]/g, '')) || 0;
      return acc + cleanMonto;
    }, 0)
  };

  const filteredVales = vales.filter(v => {
    const matchesSucursal = filterSucursal === "TODAS" || v.raw.sucursal === filterSucursal;
    const matchesSearch = v.raw.entregado.toLowerCase().includes(filterSearch.toLowerCase()) || 
                          v.raw.rubro.toLowerCase().includes(filterSearch.toLowerCase()) ||
                          v.raw.numVale.includes(filterSearch);
    return matchesSucursal && matchesSearch;
  });

  return (
    <div className="p-4 md:p-8 space-y-8 max-w-7xl mx-auto">
      <header className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold font-headline text-primary flex items-center gap-3">
            <LayoutDashboard className="w-8 h-8" /> 
            Panel de Auditoría
          </h1>
          <p className="text-muted-foreground">
            Gestión sincronizada con la API Maestra de Flynet.
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="icon" onClick={loadData} disabled={loading}>
            <RefreshCcw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          </Button>
          <Select value={selectedCycle} onValueChange={setSelectedCycle}>
            <SelectTrigger className="w-[240px] h-12 border-2 border-primary/20">
              <Calendar className="w-4 h-4 mr-2 text-primary" />
              <SelectValue placeholder="Ciclo" />
            </SelectTrigger>
            <SelectContent>
              {cycles.map(c => <SelectItem key={c.id} value={c.id}>{c.label}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
      </header>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="border-l-4 border-l-primary shadow-sm bg-white">
          <CardContent className="pt-6">
            <div className="flex justify-between items-center">
              <div>
                <p className="text-[10px] font-black text-muted-foreground uppercase tracking-widest">Total Ciclo</p>
                <p className="text-3xl font-black font-headline">{stats.total}</p>
              </div>
              <FileText className="w-8 h-8 text-primary/10" />
            </div>
          </CardContent>
        </Card>
        <Card className="border-l-4 border-l-emerald-600 shadow-sm bg-white">
          <CardContent className="pt-6">
            <div className="flex justify-between items-center">
              <div>
                <p className="text-[10px] font-black text-emerald-600 uppercase tracking-widest">Firmados</p>
                <p className="text-3xl font-black font-headline text-emerald-700">{stats.firmados}</p>
              </div>
              <CheckCircle className="w-8 h-8 text-emerald-600/10" />
            </div>
          </CardContent>
        </Card>
        <Card className="border-l-4 border-l-amber-500 shadow-sm bg-white">
          <CardContent className="pt-6">
            <div className="flex justify-between items-center">
              <div>
                <p className="text-[10px] font-black text-amber-600 uppercase tracking-widest">Con Ticket</p>
                <p className="text-3xl font-black font-headline text-amber-700">{stats.conTicket}</p>
              </div>
              <Receipt className="w-8 h-8 text-amber-600/10" />
            </div>
          </CardContent>
        </Card>
        <Card className="border-l-4 border-l-indigo-600 shadow-sm bg-white">
          <CardContent className="pt-6">
            <div className="flex justify-between items-center">
              <div>
                <p className="text-[10px] font-black text-indigo-600 uppercase tracking-widest">Gasto Total</p>
                <p className="text-3xl font-black font-headline text-indigo-700">$ {stats.montoTotal.toFixed(2)}</p>
              </div>
              <TrendingUp className="w-8 h-8 text-indigo-600/10" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="shadow-xl">
        <CardHeader className="flex flex-col xl:flex-row justify-between items-start xl:items-center gap-4 border-b">
          <CardTitle className="font-headline text-xl text-primary">Registro de Actividad</CardTitle>
          <div className="flex flex-wrap gap-2 w-full xl:w-auto">
            <div className="relative min-w-[200px] flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input 
                placeholder="Buscar..." 
                className="pl-9 h-10 border-2"
                value={filterSearch}
                onChange={(e) => setFilterSearch(e.target.value)}
              />
            </div>
            <Select value={filterSucursal} onValueChange={setFilterSucursal}>
              <SelectTrigger className="h-10 w-[160px] border-2">
                <Building2 className="w-4 h-4 mr-2" />
                <SelectValue placeholder="Sucursal" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="TODAS">Todas</SelectItem>
                {CONFIG.SUCURSALES.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader className="bg-muted/30">
                <TableRow>
                  <TableHead className="font-bold">Fecha</TableHead>
                  <TableHead className="font-bold">N° Vale</TableHead>
                  <TableHead className="font-bold">Personal</TableHead>
                  <TableHead className="font-bold text-right">Monto</TableHead>
                  <TableHead className="font-bold text-center">Firma</TableHead>
                  <TableHead className="font-bold text-center">Ticket</TableHead>
                  <TableHead className="text-right font-bold">Acción</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {loading ? (
                  <TableRow>
                    <TableCell colSpan={7} className="h-32 text-center text-muted-foreground">Sincronizando con DATA...</TableCell>
                  </TableRow>
                ) : filteredVales.length > 0 ? (
                  filteredVales.map((vale) => (
                    <TableRow 
                      key={vale.id} 
                      className="hover:bg-muted/10 cursor-pointer"
                      onClick={() => setPreviewVale(vale)}
                    >
                      <TableCell className="text-[10px] font-mono">{vale.raw.fecha}</TableCell>
                      <TableCell className="font-black text-primary">
                        <div className="flex items-center gap-2">
                          {vale.raw.numVale}
                          {vale.archivado && <FileCheck className="w-3 h-3 text-emerald-600" />}
                        </div>
                      </TableCell>
                      <TableCell className="uppercase text-xs font-medium">
                        {vale.raw.entregado}
                        <div className="text-[9px] text-muted-foreground lowercase">{vale.raw.sucursal}</div>
                      </TableCell>
                      <TableCell className="font-black text-indigo-700 text-right">{vale.raw.monto}</TableCell>
                      <TableCell className="text-center">
                        {vale.firmado ? (
                          <Badge className="bg-emerald-600 font-bold text-[9px]">FIRMADO</Badge>
                        ) : (
                          <Badge variant="outline" className="text-[9px] opacity-40">PENDIENTE</Badge>
                        )}
                      </TableCell>
                      <TableCell className="text-center">
                        {vale.comprobante ? (
                          <div className="flex justify-center"><ImageIcon className="w-4 h-4 text-amber-600" /></div>
                        ) : (
                          <span className="text-[9px] text-muted-foreground">---</span>
                        )}
                      </TableCell>
                      <TableCell className="text-right" onClick={(e) => e.stopPropagation()}>
                        <div className="flex justify-end gap-1">
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            className="h-8 w-8 text-primary"
                            onClick={() => setPreviewVale(vale)}
                          >
                            <Eye className="w-4 h-4" />
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            className="h-8 w-8"
                            onClick={() => window.open(vale.pdfUrl, '_blank')}
                          >
                            <ExternalLink className="w-4 h-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={7} className="h-40 text-center text-muted-foreground">Sin registros.</TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Modal de Previsualización */}
      <Dialog open={!!previewVale} onOpenChange={() => setPreviewVale(null)}>
        <DialogContent className="max-w-[900px] max-h-[90vh] overflow-y-auto bg-zinc-100 p-0 border-none">
          <DialogHeader className="p-4 bg-white border-b sticky top-0 z-10 flex flex-row items-center justify-between">
            <div>
              <DialogTitle className="font-headline text-xl text-primary">Auditoría Vale #{previewVale?.raw.numVale}</DialogTitle>
              <div className="flex gap-2 mt-1">
                {previewVale?.firmado && <Badge className="bg-emerald-100 text-emerald-700 hover:bg-emerald-100 border-emerald-200">Firma Verificada</Badge>}
                {previewVale?.comprobante && <Badge className="bg-amber-100 text-amber-700 hover:bg-amber-100 border-amber-200">Ticket Adjunto</Badge>}
              </div>
            </div>
            <div className="flex gap-2">
              <Button size="sm" variant="outline" onClick={() => window.print()} className="bg-white">
                <Download className="w-4 h-4 mr-2" /> PDF
              </Button>
            </div>
          </DialogHeader>
          <div className="p-8 flex justify-center">
            {previewVale && (
              <VoucherCard 
                {...previewVale.raw} 
                signatureUrl={previewVale.raw.firmaUrl}
                comprobanteUrl={previewVale.raw.comprobanteUrl}
              />
            )}
          </div>
        </DialogContent>
      </Dialog>
      
      <footer className="flex justify-between items-center text-[10px] text-muted-foreground font-bold uppercase tracking-widest pt-4 border-t">
        <span>Flynet Digital v3.0 • Unificado con API</span>
        <div className="flex gap-4">
          <span className="flex items-center gap-1"><div className="w-2 h-2 rounded-full bg-emerald-500"></div> Sincronizado</span>
        </div>
      </footer>
    </div>
  );
}

export default function AdminPage() {
  return (
    <Suspense fallback={<div className="p-8 text-center">Cargando...</div>}>
      <AdminContent />
    </Suspense>
  );
}