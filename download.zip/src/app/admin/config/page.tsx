"use client";

import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { CONFIG, type AppConfig, type UserRole } from "@/lib/config";
import { useToast } from "@/hooks/use-toast";
import { updateConfigAction } from "@/app/actions/config";
import { useRouter } from "next/navigation";
import { 
  Settings, 
  Building2, 
  Wallet, 
  Users, 
  Plus, 
  Trash2, 
  Save,
  Globe,
  Loader2,
  ShieldCheck
} from "lucide-react";

export default function ConfigPage() {
  const { toast } = useToast();
  const router = useRouter();
  const [localConfig, setLocalConfig] = useState<AppConfig>({ ...CONFIG });
  const [isSaving, setIsSaving] = useState(false);
  const [newSucursal, setNewSucursal] = useState("");
  const [newCaja, setNewCaja] = useState("");
  const [newEmployee, setNewEmployee] = useState({ name: "", pin: "", role: "SOLICITANTE" as UserRole });

  const handleSave = async () => {
    setIsSaving(true);
    const result = await updateConfigAction(localConfig);
    setIsSaving(false);

    if (result.success) {
      toast({ title: "Configuración guardada", description: "Cambios aplicados con éxito." });
      router.refresh();
    } else {
      toast({ variant: "destructive", title: "Error", description: result.error });
    }
  };

  const addSucursal = () => {
    if (newSucursal && !localConfig.SUCURSALES.includes(newSucursal.toUpperCase())) {
      setLocalConfig({
        ...localConfig,
        SUCURSALES: [...localConfig.SUCURSALES, newSucursal.toUpperCase()],
      });
      setNewSucursal("");
    }
  };

  const addEmployee = () => {
    if (newEmployee.name && newEmployee.pin) {
      setLocalConfig({
        ...localConfig,
        PINES: {
          ...localConfig.PINES,
          [newEmployee.name.toUpperCase()]: { pin: newEmployee.pin, role: newEmployee.role },
        },
      });
      setNewEmployee({ name: "", pin: "", role: "SOLICITANTE" });
    }
  };

  const removeEmployee = (key: string) => {
    const updatedPines = { ...localConfig.PINES };
    delete updatedPines[key];
    setLocalConfig({ ...localConfig, PINES: updatedPines });
  };

  return (
    <div className="p-4 md:p-8 space-y-8 max-w-5xl mx-auto pb-20">
      <header className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold font-headline text-primary flex items-center gap-3">
            <Settings className="w-8 h-8" /> Configuración ValeDigit
          </h1>
          <p className="text-muted-foreground">Control de acceso y puntos de venta oficiales.</p>
        </div>
        <Button onClick={handleSave} disabled={isSaving} className="flex gap-2 min-w-[140px]">
          {isSaving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
          Guardar Cambios
        </Button>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Personal con Roles */}
        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle className="font-headline flex items-center gap-2 text-xl">
              <Users className="w-5 h-5" /> Personal Autorizado y Roles
            </CardTitle>
            <CardDescription>Asigne roles específicos para controlar quién puede autorizar omisiones.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 items-end bg-muted/30 p-4 rounded-lg">
              <div className="space-y-2">
                <Label>Nombre</Label>
                <Input 
                  placeholder="Ej: JUAN PEREZ" 
                  value={newEmployee.name} 
                  onChange={(e) => setNewEmployee({...newEmployee, name: e.target.value})}
                />
              </div>
              <div className="space-y-2">
                <Label>Rol</Label>
                <Select value={newEmployee.role} onValueChange={(val: UserRole) => setNewEmployee({...newEmployee, role: val})}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="SOLICITANTE">Solicitante</SelectItem>
                    <SelectItem value="CAJERA">Cajera</SelectItem>
                    <SelectItem value="JEFE">Jefe / Gerente</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>PIN (4 dígitos)</Label>
                <Input 
                  type="password"
                  maxLength={4}
                  placeholder="****" 
                  value={newEmployee.pin} 
                  onChange={(e) => setNewEmployee({...newEmployee, pin: e.target.value})}
                />
              </div>
              <Button onClick={addEmployee} className="w-full">Añadir</Button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {/* Admin info (Read-only) */}
              <div className="flex justify-between items-center p-3 border-2 border-primary/20 rounded-md bg-primary/5">
                <div className="flex flex-col">
                  <span className="font-bold text-sm flex items-center gap-1">
                    ADMINISTRADOR <ShieldCheck className="w-3 h-3 text-primary" />
                  </span>
                  <span className="text-[10px] text-muted-foreground uppercase font-bold">PIN: 2026 (Fijo)</span>
                </div>
              </div>

              {Object.entries(localConfig.PINES).map(([name, data]) => (
                <div key={name} className="flex justify-between items-center p-3 border rounded-md bg-white">
                  <div className="flex flex-col">
                    <span className="font-bold text-sm">{name}</span>
                    <Badge variant="outline" className="w-fit text-[9px] h-4 px-1 mt-1">{data.role}</Badge>
                  </div>
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="text-destructive" 
                    onClick={() => removeEmployee(name)}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Sucursales */}
        <Card>
          <CardHeader>
            <CardTitle className="font-headline flex items-center gap-2 text-xl">
              <Building2 className="w-5 h-5" /> Sucursales
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex gap-2">
              <Input 
                placeholder="Nueva sucursal..." 
                value={newSucursal} 
                onChange={(e) => setNewSucursal(e.target.value)}
              />
              <Button size="icon" onClick={addSucursal}><Plus /></Button>
            </div>
            <div className="flex flex-wrap gap-2 pt-2">
              {localConfig.SUCURSALES.map((s, i) => (
                <Badge key={s} variant="secondary" className="pl-3 pr-1 py-1 flex gap-2 items-center text-sm">
                  {s}
                  <Button variant="ghost" size="icon" className="h-4 w-4 hover:text-destructive" onClick={() => {
                     const updated = localConfig.SUCURSALES.filter((_, idx) => idx !== i);
                     setLocalConfig({ ...localConfig, SUCURSALES: updated });
                  }}>
                    <Trash2 className="w-3 h-3" />
                  </Button>
                </Badge>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Datos Empresa */}
        <Card>
          <CardHeader>
            <CardTitle className="font-headline flex items-center gap-2 text-xl">
              <Globe className="w-5 h-5" /> Identidad
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label>Nombre de la Empresa</Label>
              <Input value={localConfig.EMPRESA} onChange={(e) => setLocalConfig({...localConfig, EMPRESA: e.target.value})} />
            </div>
            <div className="space-y-2">
              <Label>URL de API</Label>
              <Input value={localConfig.API_URL} onChange={(e) => setLocalConfig({...localConfig, API_URL: e.target.value})} />
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
