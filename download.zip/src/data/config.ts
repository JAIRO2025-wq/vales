export const configData = {
  "API_URL": "https://script.google.com/macros/s/AKfycbxIE_XohaGwm6rMEHIoNIzj93WBB2Zd0kkgaJ-QDWU7Ina8p5-hTNcTI3iNxZ8qlTO4eg/exec",
  "PINES": {
    "VICENTE": { "pin": "4444", "role": "JEFE" },
    "JAIRO": { "pin": "1111", "role": "CAJERA" },
    "MARIA": { "pin": "2222", "role": "SOLICITANTE" }
  },
  "EMPRESA": "FLYNET S.A. de C.V.",
  "LOGO_URL": "/logo.svg",
  "SUCURSALES": [
    "SAN MIGUEL",
    "USULUTAN",
    "LA UNION"
  ],
  "TIPOS_CAJA": [
    "Caja chica",
    "Clientes",
    "Instalaciones"
  ]
};
