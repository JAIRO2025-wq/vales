"use client";

import React from "react";
import { useToast } from "@/hooks/use-toast";
import { Share2, Copy, ShieldCheck } from "lucide-react";

interface VoucherCardProps {
  id: string;
  fecha: string;
  entregado: string;
  rubro: string;
  numVale: string;
  monto: string;
  sucursal: string;
  sheet: string;
  qrUrl?: string;
  qrFileUrl?: string;
  rawSignUrl?: string;
  rawFileUrl?: string;
  signatureUrl?: string;
  comprobanteUrl?: string;
  motivoOmitido?: string;
}

export const VoucherCard: React.FC<VoucherCardProps> = ({
  id,
  fecha,
  entregado,
  rubro,
  numVale,
  monto,
  sucursal,
  sheet,
  qrUrl,
  qrFileUrl,
  rawSignUrl,
  rawFileUrl,
  signatureUrl,
  comprobanteUrl,
  motivoOmitido,
}) => {
  const { toast } = useToast();
  const displayMonto = monto.replace("$", "").trim();
  const sheetUpper = (sheet || "").toUpperCase();
  
  const isCajaChica = sheetUpper.includes("CHICA") || sheetUpper === "HOJA 1" || sheetUpper.includes("GENERAL");
  const isClientes = sheetUpper.includes("CLIENTES");
  const isInstalaciones = sheetUpper.includes("INSTALACIONES");

  const isSigned = !!(signatureUrl || (motivoOmitido && motivoOmitido.trim().length > 2));

  const handleAction = async (url: string | undefined, label: string) => {
    if (!url) return;
    try {
      await navigator.clipboard.writeText(url);
      toast({
        title: "¡Enlace Copiado!",
        description: `El link de ${label} se guardó en el portapapeles.`,
      });
    } catch (err) {}
  };

  const handleShare = async (e: React.MouseEvent, url: string | undefined, label: string) => {
    e.stopPropagation();
    if (!url) return;
    if (navigator.share) {
      try {
        await navigator.share({
          title: `Vale Flynet #${numVale}`,
          text: `Enlace para ${label} del Vale de Caja #${numVale}`,
          url: url,
        });
      } catch (err) {}
    } else {
      handleAction(url, label);
    }
  };

  return (
    <div className="vale-view-wrapper flex flex-col items-center gap-8 print:p-0">
      <style jsx>{`
        .vale-container {
          width: 850px;
          background: #ffffff;
          border: 1px solid #1a1a1a;
          padding: 40px;
          position: relative;
          box-shadow: 0 10px 40px rgba(0,0,0,0.08);
          color: #000;
          font-family: 'Inter', sans-serif;
        }

        .vale-container::before {
          content: "";
          position: absolute;
          top: 0; left: 0; right: 0; bottom: 0;
          border: 12px double #f0f0f0;
          pointer-events: none;
        }

        .watermark {
          position: absolute;
          top: 50%;
          left: 50%;
          transform: translate(-50%, -50%) rotate(-30deg);
          font-size: 150px;
          font-weight: 900;
          color: rgba(0, 0, 0, 0.03);
          pointer-events: none;
          user-select: none;
          z-index: 0;
          text-transform: uppercase;
        }

        .header-top {
          display: flex;
          justify-content: space-between;
          align-items: flex-start;
          margin-bottom: 30px;
          position: relative;
          z-index: 1;
        }

        .logo-box h2 {
          font-size: 42px;
          font-weight: 900;
          font-style: italic;
          line-height: 0.8;
          letter-spacing: -2px;
        }

        .logo-box span {
          font-size: 10px;
          text-transform: uppercase;
          letter-spacing: 2px;
          font-weight: 600;
        }

        .title-badge {
          background: #000;
          color: #fff;
          padding: 8px 25px;
          font-weight: 800;
          letter-spacing: 3px;
          font-size: 16px;
          transform: skewX(-10deg);
        }

        .voucher-number {
          display: flex;
          align-items: center;
          gap: 10px;
          font-size: 20px;
          font-weight: 800;
        }

        .number-box {
          border-bottom: 2px solid #000;
          min-width: 100px;
          text-align: center;
          color: #d32f2f;
        }

        .info-grid {
          display: grid;
          grid-template-columns: 1fr auto;
          gap: 40px;
          margin-bottom: 30px;
          position: relative;
          z-index: 1;
        }

        .categories {
          display: flex;
          gap: 30px;
        }

        .cat-item {
          display: flex;
          align-items: center;
          gap: 8px;
          font-weight: 700;
          font-size: 14px;
        }

        .checkbox {
          width: 18px;
          height: 18px;
          border: 2px solid #000;
          display: flex;
          align-items: center;
          justify-content: center;
        }

        .checkbox.active::after {
          content: "✓";
          font-size: 14px;
        }

        .main-fields {
          margin-bottom: 30px;
          position: relative;
          z-index: 1;
        }

        .field-row {
          display: flex;
          align-items: flex-end;
          margin-bottom: 15px;
          gap: 15px;
        }

        .label {
          font-size: 13px;
          font-weight: 800;
          text-transform: uppercase;
          white-space: nowrap;
          color: #444;
        }

        .line-value {
          flex: 1;
          border-bottom: 1px dashed #999;
          font-size: 16px;
          font-weight: 600;
          padding-bottom: 2px;
          text-transform: uppercase;
        }

        .amount-section {
          display: flex;
          justify-content: flex-end;
          margin-top: 20px;
        }

        .amount-display {
          border: 3px solid #000;
          padding: 5px 20px;
          display: flex;
          align-items: center;
          gap: 15px;
          background: #f8f8f8;
        }

        .amount-display .currency {
          font-size: 24px;
          font-weight: 900;
        }

        .amount-display .value {
          font-size: 28px;
          font-weight: 900;
          font-family: 'Courier New', monospace;
        }

        .footer-signatures {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 100px;
          margin-top: 50px;
          padding: 0 40px;
          position: relative;
          z-index: 1;
        }

        .sig-block {
          text-align: center;
        }

        .sig-space {
          height: 80px;
          display: flex;
          align-items: center;
          justify-content: center;
          margin-bottom: 5px;
        }

        .sig-image {
          max-height: 80px;
          mix-blend-mode: multiply;
        }

        .sig-line {
          border-top: 2px solid #000;
          padding-top: 5px;
          font-size: 12px;
          font-weight: 800;
          text-transform: uppercase;
        }

        .sig-subtitle {
          font-size: 10px;
          color: #666;
          font-style: italic;
        }

        .omitted-badge {
          background: #fff5f5;
          border: 1px solid #feb2b2;
          color: #c53030;
          font-size: 11px;
          padding: 5px;
          font-weight: 700;
        }

        .stamp-procesado {
          position: absolute;
          top: 40px;
          right: 200px;
          border: 4px solid #38a169;
          color: #38a169;
          padding: 5px 15px;
          font-size: 24px;
          font-weight: 900;
          text-transform: uppercase;
          transform: rotate(-15deg);
          opacity: 0.8;
          border-radius: 8px;
          z-index: 10;
        }

        .qr-area {
          display: flex;
          justify-content: center;
          gap: 40px;
          margin-top: 30px;
          border-top: 1px solid #eee;
          padding-top: 20px;
        }

        .qr-card {
          display: flex;
          align-items: center;
          gap: 15px;
          background: #fdfdfd;
          padding: 10px;
          border: 1px solid #efefef;
          border-radius: 8px;
          cursor: pointer;
          transition: transform 0.2s;
        }

        .qr-card:hover {
          transform: translateY(-2px);
          background: #fff;
          box-shadow: 0 5px 15px rgba(0,0,0,0.05);
        }

        .qr-img {
          width: 80px;
          height: 80px;
          border: 1px solid #000;
        }

        .qr-meta h4 {
          font-size: 12px;
          font-weight: 800;
          margin: 0;
        }

        .qr-meta p {
          font-size: 10px;
          color: #666;
          margin: 0;
        }

        .attachment-box {
          width: 850px;
          background: #fff;
          border: 1px solid #000;
          margin-top: 20px;
          padding: 20px;
        }

        @media print {
          .vale-container {
            box-shadow: none;
            border: 1px solid #000;
            width: 100%;
          }
          .qr-area, .vale-view-wrapper > button {
            display: none !important;
          }
        }
      `}</style>

      {/* CUERPO DEL VALE */}
      <div id="valeContainer" className="vale-container">
        <div className="watermark">flynet</div>
        
        {isSigned && (
          <div className="stamp-procesado">
            VALE PROCESADO
          </div>
        )}

        <div className="header-top">
          <div className="logo-box">
            <h2>flynet</h2>
            <span>S.A. de C.V.</span>
          </div>
          <div className="title-badge">VALE DE CAJA</div>
          <div className="voucher-number">
            <span>N°</span>
            <div className="number-box">{numVale}</div>
          </div>
        </div>

        <div className="info-grid">
          <div className="categories">
            <div className="cat-item">
              <div className={`checkbox ${isCajaChica ? 'active' : ''}`}></div>
              <span>CAJA CHICA</span>
            </div>
            <div className="cat-item">
              <div className={`checkbox ${isClientes ? 'active' : ''}`}></div>
              <span>CLIENTES</span>
            </div>
            <div className="cat-item">
              <div className={`checkbox ${isInstalaciones ? 'active' : ''}`}></div>
              <span>INSTALACIONES</span>
            </div>
          </div>
          <div className="field-row" style={{marginBottom: 0}}>
            <span className="label">FECHA:</span>
            <span className="line-value" style={{minWidth: '150px'}}>{fecha}</span>
          </div>
        </div>

        <div className="main-fields">
          <div className="field-row">
            <span className="label">PAGADO A:</span>
            <span className="line-value">{entregado}</span>
          </div>
          <div className="field-row">
            <span className="label">LA SUMA DE:</span>
            <span className="line-value" style={{textTransform: 'none'}}>
              {displayMonto} <small className="opacity-50">/100 DOLARES</small>
            </span>
          </div>
          <div className="field-row">
            <span className="label">POR CONCEPTO DE:</span>
            <span className="line-value" style={{textTransform: 'none'}}>{rubro}</span>
          </div>
        </div>

        <div className="amount-section">
          <div className="amount-display">
            <span className="currency">$</span>
            <span className="value">{displayMonto}</span>
          </div>
        </div>

        <div className="footer-signatures">
          <div className="sig-block">
            <div className="sig-space">
              {signatureUrl && <img src={signatureUrl} alt="Firma" className="sig-image" />}
              {motivoOmitido && <div className="omitted-badge">OMITIDO: {motivoOmitido}</div>}
            </div>
            <div className="sig-line">FIRMA DEL SOLICITANTE</div>
            <div className="sig-subtitle">{entregado}</div>
          </div>
          
          <div className="sig-block">
            <div className="sig-space" style={{alignItems: 'flex-end', paddingBottom: '10px'}}>
               <span className="font-bold text-sm">AUTORIZACIÓN DIGITAL</span>
            </div>
            <div className="sig-line">GERENCIA / CAJA</div>
            <div className="sig-subtitle">{sucursal}</div>
          </div>
        </div>

        {/* ÁREA DE ACCIONES QR (Oculto en impresión) */}
        {!isSigned && (qrUrl || qrFileUrl) && (
          <div className="qr-area print:hidden">
            {qrUrl && (
              <div className="qr-card" onClick={() => handleAction(rawSignUrl, "Firma")}>
                <img src={qrUrl} className="qr-img" alt="QR Firma" />
                <div className="qr-meta">
                  <h4>FIRMA DIGITAL</h4>
                  <p>Click para copiar link</p>
                  <div className="flex gap-1 mt-1">
                    <button onClick={(e) => handleShare(e, rawSignUrl, "Firma")} className="bg-blue-600 text-white p-1 rounded"><Share2 size={10}/></button>
                    <button className="bg-zinc-800 text-white p-1 rounded" onClick={() => handleAction(rawSignUrl, "Firma")}><Copy size={10}/></button>
                  </div>
                </div>
              </div>
            )}

            {qrFileUrl && (
              <div className="qr-card" onClick={() => handleAction(rawFileUrl, "Comprobante")}>
                <img src={qrFileUrl} className="qr-img" alt="QR Comprobante" />
                <div className="qr-meta">
                  <h4>ADJUNTAR TICKET</h4>
                  <p>Click para copiar link</p>
                  <div className="flex gap-1 mt-1">
                    <button onClick={(e) => handleShare(e, rawFileUrl, "Comprobante")} className="bg-emerald-600 text-white p-1 rounded"><Share2 size={10}/></button>
                    <button className="bg-zinc-800 text-white p-1 rounded" onClick={() => handleAction(rawFileUrl, "Comprobante")}><Copy size={10}/></button>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* COMPROBANTE ADJUNTO (Si existe) */}
      {comprobanteUrl && (
        <div className="attachment-box">
          <div className="border-b-2 border-black pb-2 mb-4 flex justify-between items-center">
            <span className="font-black text-sm uppercase tracking-widest">Comprobante de Gasto Adjunto</span>
            <ShieldCheck className="text-emerald-600" size={20} />
          </div>
          <div className="flex justify-center bg-gray-50 p-4">
            <img src={comprobanteUrl} alt="Comprobante" className="max-w-full max-h-[500px] object-contain shadow-md" />
          </div>
        </div>
      )}
    </div>
  );
};
